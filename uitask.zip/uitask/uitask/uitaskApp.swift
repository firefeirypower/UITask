//
//  uitaskApp.swift
//  uitask
//
//  Created by Анастасія Локайчук on 18.06.2022.
//

import SwiftUI

@main
struct uitaskApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
